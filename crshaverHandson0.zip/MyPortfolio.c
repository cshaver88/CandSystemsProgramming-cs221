/* File:     MyPortfolio.c
 * Purpose:  Tell Professor about me.
 * Output:   My Information
 *
 * Compile:  gcc -g -Wall -o me MyPortfolio.c
 * Run:      ./me
 *
 */
#include <stdio.h>


/*------------------------------------------------------------*/
 int main (void) {
 	printf("My name is Cayla Shaver\n");
 	printf("The courses I have taken are : \n");
 	printf("- Java \n");
 	printf("- JavaCC \n");
 	printf("- C \n"); 
 	printf("- Appinventor \n");
 	printf("- Groovy \n");
 	printf("- Javascript \n"); 
 	printf("- Python\n");

 	return 0;
 } /* main */

