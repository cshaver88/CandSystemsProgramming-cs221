#!/bin/sh/

sed 's/|/=/g' alltime.txt